Sparkify has been collecting data on user activity in relation to song consumption. The purpose of this database to to understand what songs the users are listening to. The goal was to optimize queries on song play analysis. This was acomplished using an ETL Pipeline that connected the data from the Songs/Artist song data with the User/Time logs data into a single database. 

State and justify your database schema design and ETL pipeline.
The schema used was a star schema. The benifit of this was that it allowed us to simplify the queries that the analytics team were looking for. The ETL Pipeline allowed us to merge two data sets, trasnform the data to drop the unnecessary columns and rows, and then load it into a PostgreSQL Database for data analytics.
![](schema.jpg)
